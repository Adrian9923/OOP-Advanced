package santasWorkshop.models;

public class Sleepy extends BaseDwarf{
    public Sleepy(String name) {
        super(name, 50);
    }
}
