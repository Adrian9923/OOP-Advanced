package santasWorkshop.models;

public class InstrumentImpl implements Instrument{
    private int power;

    public InstrumentImpl(int power) {
        this.setPower(power);
    }

    public void setPower(int power) {
        if (power < 0) {
            throw new IllegalArgumentException("Cannot create an Instrument with negative power!");
        }
        this.power = power;
    }

    @Override
    public int getPower() {
        return this.power;
    }

    @Override
    public void use() {
        if (this.getPower() - 10 < 0) {
            this.setPower(0);
        }else {
            this.setPower(this.getPower() - 10);
        }
    }

    @Override
    public boolean isBroken() {
        return this.getPower() == 0;
    }
}
